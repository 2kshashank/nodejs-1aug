export function getDateTime(){
    return new Date().toISOString();
}

export function getDate(){
    return new Date().getDate();
}

export const applicationName = "TCS Demo Project"